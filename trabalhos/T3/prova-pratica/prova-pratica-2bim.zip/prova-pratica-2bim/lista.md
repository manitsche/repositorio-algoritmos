<!-- LIST_ID=3 -->

# Prova Pratica 2Bim

**Prazo:** sem prazo

| # | Exercício | Nota | Máximo |
|---|-----------|-----:|-------:|
| 1 | Remoção de Duplicados Consecutivos | — | 26 |
| 2 | Aplicar Máscara em Vetor | — | 24 |
| 3 | E Lógico entre Vetores | — | 23 |
| 4 | Obter Coluna de Matriz | — | 23 |

**Total: — / 96**

*Abra este arquivo no VSCode e clique em ☁ Consultar para atualizar.*