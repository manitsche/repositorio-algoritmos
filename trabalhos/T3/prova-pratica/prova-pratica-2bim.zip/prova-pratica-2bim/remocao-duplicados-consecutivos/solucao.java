// ==SUBMIT==
// PROBLEM_ID=15
// LANG=java
// LIST_PROBLEM_ID=15
// ==SUBMIT==

import java.util.Scanner;

public class Main {

    public static String removerDuplicados(String s) {
        // TODO: implemente a remoção de duplicados consecutivos aqui
        
        //Variáveis
        
        //Processamento
        
        //Retorno
        return null;
    }

    public static void main(String[] args) {
        // Variáveis
        Scanner entrada;
        String s, resultado;

        // Entrada
        entrada = new Scanner(System.in);
        s = entrada.nextLine();

        // Processamento
        resultado = removerDuplicados(s);

        // Saída
        System.out.println(resultado);
    }
}
