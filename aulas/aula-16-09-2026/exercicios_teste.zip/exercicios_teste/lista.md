<!-- LIST_ID=2 -->

# Simulado 2º Bimestre — Strings, Vetores e Matrizes

**Prazo:** sem prazo

| # | Exercício | Nota | Máximo |
|---|-----------|-----:|-------:|
| 1 | Substituição de Caracteres | — | 26 |
| 2 | Negação de Vetor Lógico | — | 25 |
| 3 | Filtrar Valores Maiores | — | 25 |
| 4 | Busca por Valor em Matriz | — | 25 |

**Total: — / 101**

*Abra este arquivo no VSCode e clique em ☁ Consultar para atualizar.*