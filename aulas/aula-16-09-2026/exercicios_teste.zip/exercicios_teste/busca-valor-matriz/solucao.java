// ==SUBMIT==
// PROBLEM_ID=14
// LANG=java
// LIST_PROBLEM_ID=14
// ==SUBMIT==

import java.util.Scanner;

public class Main {

    public static int[][] buscarValor(int[][] matriz, int x) {
        // TODO: implemente a busca aqui (retorne uma matriz P x 2 com as posições
        // "linha coluna" em que x ocorre, na ordem de leitura da matriz)
        return null;
    }

    public static void mostrarVetor(int[] vetor) {
        StringBuilder sb = new StringBuilder();
        sb.append('[');
        for (int i = 0; i < vetor.length; i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append(vetor[i]);
        }
        sb.append(']');
        System.out.println(sb.toString());
    }

    public static void mostrarMatriz(int[][] matriz) {
        for (int[] linha : matriz) {
            mostrarVetor(linha);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int r = sc.nextInt();
        int c = sc.nextInt();

        int[][] matriz = new int[r][c];
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                matriz[i][j] = sc.nextInt();
            }
        }

        int x = sc.nextInt();

        int[][] posicoes = buscarValor(matriz, x);

        System.out.println(posicoes.length);
        mostrarMatriz(posicoes);
    }
}
